import { campeonato } from './campeonato.js';

document.addEventListener('DOMContentLoaded', () => {
  console.log(campeonato);

  const grupos = {
    A: [],
    B: [],
    C: [],
    D: []
  };

  for (let i = 0; i < campeonato.length; i++) {
    const grupo = String.fromCharCode(65 + Math.floor(i / 4)); 
    grupos[grupo].push(campeonato[i]);
  }

  function gerarTabela(grupo, grupoNome) {
    const tbody = document.querySelector(`#grupo-${grupoNome} tbody`);

    grupos[grupo].forEach(time => {
      const tr = document.createElement('tr');

      for (let i = 0; i < 9; i++) {
        const td = document.createElement('td');
        tr.appendChild(td);
      }

      tbody.appendChild(tr);
    });

    let trs = document.querySelectorAll(`#grupo-${grupoNome} tbody tr`);
    for (let index = 0; index < trs.length; index++) {
      let listaDeFilhos = obterFilhos(trs[index]);
      editarFilhos(listaDeFilhos, grupo, index);
    }
  }

  function obterFilhos(tr) {
    return Array.from(tr.children);
  }

  function editarFilhos(listaDeFilhos, grupo, index) {
    listaDeFilhos[0].textContent = grupos[grupo][index].posicao;
    listaDeFilhos[1].textContent = grupos[grupo][index].time;
    listaDeFilhos[2].textContent = grupos[grupo][index].pontos;
    listaDeFilhos[3].textContent = grupos[grupo][index].vitorias;
    listaDeFilhos[4].textContent = grupos[grupo][index].empates;
    listaDeFilhos[5].textContent = grupos[grupo][index].derrotas;
    listaDeFilhos[6].textContent = grupos[grupo][index].gols_pro;
    listaDeFilhos[7].textContent = grupos[grupo][index].gols_contra;
    listaDeFilhos[8].textContent = grupos[grupo][index].saldo_gols;
  }

  gerarTabela('A', 'A');
  gerarTabela('B', 'B');
  gerarTabela('C', 'C');
  gerarTabela('D', 'D');
});
