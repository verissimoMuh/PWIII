 const campeonato = 
    [
      {
        "posicao": 1,
        "time": "Corinthians",
        "pontos": 27,
        "vitorias": 8,
        "empates": 3,
        "derrotas": 1,
        "gols_pro": 20,
        "gols_contra": 13,
        "saldo_gols": 7
      },
      {
        "posicao": 2,
        "time": "São Bernardo",
        "pontos": 23,
        "vitorias": 7,
        "empates": 2,
        "derrotas": 3,
        "gols_pro": 19,
        "gols_contra": 15,
        "saldo_gols": 4
      },
      {
        "posicao": 3,
        "time": "Palmeiras",
        "pontos": 23,
        "vitorias": 6,
        "empates": 5,
        "derrotas": 1,
        "gols_pro": 21,
        "gols_contra": 10,
        "saldo_gols": 11
      },
      {
        "posicao": 4,
        "time": "Ponte Preta",
        "pontos": 22,
        "vitorias": 6,
        "empates": 4,
        "derrotas": 2,
        "gols_pro": 12,
        "gols_contra": 8,
        "saldo_gols": 4
      },
      {
        "posicao": 5,
        "time": "São Paulo",
        "pontos": 19,
        "vitorias": 5,
        "empates": 4,
        "derrotas": 3,
        "gols_pro": 18,
        "gols_contra": 13,
        "saldo_gols": 5
      },
      {
        "posicao": 6,
        "time": "Santos",
        "pontos": 18,
        "vitorias": 5,
        "empates": 3,
        "derrotas": 4,
        "gols_pro": 20,
        "gols_contra": 14,
        "saldo_gols": 6
      },
      {
        "posicao": 7,
        "time": "Novorizontino",
        "pontos": 18,
        "vitorias": 4,
        "empates": 6,
        "derrotas": 2,
        "gols_pro": 13,
        "gols_contra": 11,
        "saldo_gols": 2
      },
      {
        "posicao": 8,
        "time": "Mirassol",
        "pontos": 17,
        "vitorias": 5,
        "empates": 2,
        "derrotas": 5,
        "gols_pro": 21,
        "gols_contra": 20,
        "saldo_gols": 1
      },
      {
        "posicao": 9,
        "time": "Bragantino",
        "pontos": 17,
        "vitorias": 5,
        "empates": 2,
        "derrotas": 5,
        "gols_pro": 14,
        "gols_contra": 13,
        "saldo_gols": 1
      },
      {
        "posicao": 10,
        "time": "Guarani",
        "pontos": 13,
        "vitorias": 3,
        "empates": 4,
        "derrotas": 5,
        "gols_pro": 14,
        "gols_contra": 14,
        "saldo_gols": 0
      },
      {
        "posicao": 11,
        "time": "Velo Clube",
        "pontos": 13,
        "vitorias": 3,
        "empates": 4,
        "derrotas": 5,
        "gols_pro": 13,
        "gols_contra": 16,
        "saldo_gols": -3
      },
      {
        "posicao": 12,
        "time": "Portuguesa",
        "pontos": 13,
        "vitorias": 2,
        "empates": 7,
        "derrotas": 3,
        "gols_pro": 15,
        "gols_contra": 16,
        "saldo_gols": -1
      },
      {
        "posicao": 13,
        "time": "Botafogo-SP",
        "pontos": 11,
        "vitorias": 2,
        "empates": 5,
        "derrotas": 5,
        "gols_pro": 8,
        "gols_contra": 13,
        "saldo_gols": -5
      },
      {
        "posicao": 14,
        "time": "Noroeste",
        "pontos": 8,
        "vitorias": 1,
        "empates": 5,
        "derrotas": 6,
        "gols_pro": 12,
        "gols_contra": 19,
        "saldo_gols": -7
      },
      {
        "posicao": 15,
        "time": "Água Santa",
        "pontos": 7,
        "vitorias": 1,
        "empates": 4,
        "derrotas": 7,
        "gols_pro": 10,
        "gols_contra": 23,
        "saldo_gols": -13
      },
      {
        "posicao": 16,
        "time": "Inter de Limeira",
        "pontos": 7,
        "vitorias": 0,
        "empates": 7,
        "derrotas": 5,
        "gols_pro": 9,
        "gols_contra": 19,
        "saldo_gols": -10
      }
    ];
  
    export  {campeonato};