document.getElementById("formReserva").addEventListener("submit", function(e) {
    e.preventDefault();
    
    const reserva = document.getElementById("reserva").value.trim();
    const email = document.getElementById("email").value.trim();
    
    if(reserva && email) {
      alert(`🔎 Procurando reserva...\nN°: ${reserva}\nEmail: ${email}`);
      // Aqui você pode colocar uma chamada para a API ou back-end
    } else {
      alert("⚠️ Por favor, preencha todos os campos.");
    }
  });
  