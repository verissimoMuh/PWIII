const reserva = {
    suite: "SUÍTE HIDRO PREMIUM",
    data: "01/09/2025",
    valor: "85,00",
    email: "LYDIA06@GMAIL.COM",
    obs: "MUSICA AMBIENTE"
  };

  // Preenche os spans com os dados
  document.getElementById('suite').textContent = reserva.suite;
  document.getElementById('data-reserva').textContent = reserva.data;
  document.getElementById('valor').textContent = reserva.valor;
  document.getElementById('email').textContent = reserva.email;
  document.getElementById('obs').textContent = reserva.obs;