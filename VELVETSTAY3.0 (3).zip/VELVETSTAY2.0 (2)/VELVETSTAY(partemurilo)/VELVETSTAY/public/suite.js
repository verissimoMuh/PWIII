document.addEventListener('DOMContentLoaded', () => {
    const imgs = document.querySelectorAll('.container .carousel img');
    let current = 0;
 
    const showImage = (index) => {
      imgs.forEach((img, i) => {
        img.classList.toggle('active', i === index);
      });
    };
 
    document.getElementById('next').addEventListener('click', () => {
      current = (current + 1) % imgs.length;
      showImage(current);
    });
 
    document.getElementById('prev').addEventListener('click', () => {
      current = (current - 1 + imgs.length) % imgs.length;
      showImage(current);
    });
  });