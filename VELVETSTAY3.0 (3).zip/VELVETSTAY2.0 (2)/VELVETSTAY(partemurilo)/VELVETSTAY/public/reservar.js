
document.addEventListener("DOMContentLoaded", () => {
    const daysContainer = document.getElementById("days");
    const monthYear = document.getElementById("month-year");
    const prevBtn = document.getElementById("prev");
    const nextBtn = document.getElementById("next");
    const continueBtn = document.getElementById("continue-btn");
  
    let currentDate = new Date();
    let selectedDate = null;
  
    // Função para renderizar o calendário
    function renderCalendar(date) {
      const year = date.getFullYear();
      const month = date.getMonth();
  
      monthYear.textContent = date.toLocaleDateString("pt-BR", {
        month: "long",
        year: "numeric",
      });
  
      daysContainer.innerHTML = "";
  
      const firstDay = new Date(year, month, 1).getDay();
      const lastDate = new Date(year, month + 1, 0).getDate();
  
      // Preenche dias em branco
      for (let i = 0; i < firstDay; i++) {
        const emptyCell = document.createElement("div");
        daysContainer.appendChild(emptyCell);
      }
  
      // Preenche os dias do mês
      for (let day = 1; day <= lastDate; day++) {
        const dayCell = document.createElement("div");
        dayCell.textContent = day;
  
        // Clique para selecionar data
        dayCell.addEventListener("click", () => {
          selectedDate = new Date(year, month, day);
  
          document.querySelectorAll("#days div").forEach((d) =>
            d.classList.remove("selected")
          );
          dayCell.classList.add("selected");
  
          continueBtn.disabled = false;
        });
  
        daysContainer.appendChild(dayCell);
      }
    }
  
    // Navegação entre meses
    prevBtn.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() - 1);
      renderCalendar(currentDate);
    });
  
    nextBtn.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() + 1);
      renderCalendar(currentDate);
    });
  
    // Botão continuar -> envia para page2
    continueBtn.addEventListener("click", () => {
      if (selectedDate) {
        localStorage.setItem("selectedDate", selectedDate.toISOString());
        window.location.href = "page2.html";
      }
    });
  
    renderCalendar(currentDate);
  });
  