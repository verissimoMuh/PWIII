// Importa o Express
const express = require('express');
const path = require('path');


// Cria o app Express
const app = express();

// Define a porta em que o servidor vai rodar
const PORT = 3000;

// Serve arquivos estáticos da pasta "public"
app.use(express.static(path.join(__dirname, 'public')));

// Rota para servir a página HTML
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Rota para servir a página HTML
app.get('/suite', (req, res) => {
  res.sendFile(path.join(__dirname, 'suite.html'));
});

app.get('/reservar', (req, res) => {
  res.sendFile(path.join(__dirname, 'reservar.html'));
});

app.get('/hospede', (req, res) => {
  res.sendFile(path.join(__dirname, 'hospede.html'));
});

app.get('/confirmacao', (req, res) => {
  res.sendFile(path.join(__dirname, 'confirmacao.html'));
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na http://localhost:${PORT}`);
});


// LOGIN
if (window.location.pathname.includes("index.html")) {
  document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value.trim();
    const erro = document.getElementById("erro");

    if (email === "admin@hotel.com" && senha === "123456") {
      // Salva flag de login e redireciona
      localStorage.setItem("logado", "true");
      window.location.href = "dashboard.html";
    } else {
      erro.textContent = "E-mail ou senha inválidos.";
    }
  });
}

// DASHBOARD
if (window.location.pathname.includes("dashboard.html")) {
  if (localStorage.getItem("logado") !== "true") {
    alert("Você precisa fazer login primeiro.");
    window.location.href = "dashboardDados.html";
  }

  // Carrega Google Charts
  google.charts.load("current", { packages: ["corechart"] });
  google.charts.setOnLoadCallback(desenharGrafico);

  async function desenharGrafico() {
    const resposta = await fetch("reservas.json");
    const reservas = await resposta.json();

    // Contar reservas por e-mail
    const contagem = {};
    reservas.forEach(r => {
      contagem[r.email] = (contagem[r.email] || 0) + 1;
    });

    const dadosArray = [["Email", "Reservas"]];
    for (const email in contagem) {
      dadosArray.push([email, contagem[email]]);
    }

    const data = google.visualization.arrayToDataTable(dadosArray);
    const options = {
      title: "Reservas por E-mail",
      legend: { position: "none" },
      hAxis: { title: "E-mail" },
      vAxis: { title: "Qtd de Reservas" },
    };

    const chart = new google.visualization.ColumnChart(document.getElementById("grafico"));
    chart.draw(data, options);

    // Popular tabela
    const tabela = document.querySelector("#tabelaReservas tbody");
    reservas.forEach(r => {
      const linha = document.createElement("tr");
      linha.innerHTML = `<td>${r.nome}</td><td>${r.email}</td><td>${r.data}</td>`;
      tabela.appendChild(linha);
    });
  }
}
