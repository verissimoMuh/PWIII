const express = require('express')
const env = require('dotenv')

const {buscarClientes, buscarCliente} = require('./src/DAO/cliente/buscar_cliente.js')
const {incluirCliente} = require('./src/DAO/cliente/inserir_cliente.js')
const {buscarStatus, buscarStatu } = require('./src/DAO/status/buscar_status.js')
const {incluirStatus} = require('./src/DAO/status/inserir_status.js')
const {buscarCategorias, buscarCategoria} = require('./src/DAO/categoria/buscar_categoria.js')
const {incluirCategoria} = require('./src/DAO/categoria/inserir_categoria.js')
const {buscarProdutos, buscarProduto} = require('./src/DAO/produtos/buscar_produtos.js')
const {incluirProduto} = require('./src/DAO/produtos/inserir_produtos.js')
const {buscarEnderecos, buscarEndereco} = require('./src/DAO/endereco/buscar_Endereco.js')
const {incluirEndereco} = require('./src/DAO/endereco/inserir_Endereco.js')
const {buscarItemPedidos, buscarItemPedido} = require('./src/DAO/itemPedido/buscar_itemPedido.js')
const {incluirItemPedido} = require('./src/DAO/itemPedido/inserir_itemPedido.js')
const {buscarPedidos, buscarPedido} = require('./src/DAO/pedido/buscar_pedido.js')
const {incluirPedido} = require('./src/DAO/pedido/inserir_pedido.js')
    



const {conexao, closeConexao, testarConexao} = require('./src/DAO/conexao.js')

const app = express()
env.config()

app.use(
    express.urlencoded({
        extended: true
    })
  )
  
  app.use(express.json())
  


app.get('/', (req, res) => {
  res.send('Hello World')
})


//cliente
app.get('/firma/1.0.0/cliente', async (req, res) =>{
    let clientes = await buscarClientes()
    res.json(clientes)
})

app.get('/firma/1.0.0/cliente/:codigo', async (req, res) =>{
    let codigo = parseInt( req.params.codigo)
    let cliente = await buscarCliente(codigo)
    res.json(cliente)
})

app.post('/firma/1.0.0/cliente', async (req, res) =>{
    let {codigo, nome, limite, telefone, id_endereco, id_status} = req.body
    const infos = [codigo, nome, telefone, limite, id_endereco, id_status]
    let result = await incluirCliente(infos)
    res.json(result)
})

//status
app.get('/firma/1.0.0/status', async (req, res) =>{
    let status = await buscarStatus()
    res.json(status)
})

app.get('/firma/1.0.0/status/:id', async (req, res) =>{
    let codigo = parseInt( req.params.id)
    let statu = await buscarStatu(id)
    res.json(statu)
})

app.post('/firma/1.0.0/status', async (req, res) =>{
    let {id, nome} = req.body
    const infos = [id, nome]
    let result = await incluirStatus(infos)
    res.json(result)
})

//categoria
app.get('/firma/1.0.0/categoria', async (req, res) =>{
    let status = await buscarCategorias()
    res.json(categorias)
})

app.get('/firma/1.0.0/categoria/:id', async (req, res) =>{
    let id = parseInt( req.params.id)
    let statu = await buscarCategoria(id)
    res.json(categoria)
})

app.post('/firma/1.0.0/categoria', async (req, res) =>{
    let {id, nome} = req.body
    const infos = [id, nome]
    let result = await incluirCategoria(infos)
    res.json(result)
})


//Produtos

app.get('/firma/1.0.0/produtos', async (req, res) =>{
    let produtos = await buscarProdutos()
    res.json(produtos)
})
app.get('/firma/1.0.0/produtos/:codigo', async (req, res) =>{
    let codigo = parseInt( req.params.codigo)
    let produto = await buscarProduto(codigo)
    res.json(produto)
})
app.post('/firma/1.0.0/produtos', async (req, res) =>{
    let {codigo,nome, id_categoria, preco} = req.body
    const infos = [codigo,nome, id_categoria, preco]
    let resultProduto = await incluirProduto(infos)
    res.json(resultProduto)
})


//enderecos
app.get('/firma/1.0.0/endereco', async (req, res) =>{
    let enderecos = await buscarEnderecos()
    res.json(enderecos)
})
app.get('/firma/1.0.0/endereco/:id', async (req, res) =>{
    let id = parseInt( req.params.id)
    let endereco = await buscarEndereco(id)
    res.json(endereco)
})
app.post('/firma/1.0.0/endereco', async (req, res) =>{
    let {id, logradouro, cep, numero, bairro,  cidade} = req.body
    const infos = [id, logradouro, cep, numero, bairro,  cidade]
    let resultEndereco = await incluirEndereco(infos)
    res.json(resultEndereco)
})

//ItemPEdido



app.get('/firma/1.0.0/itemPedido', async (req, res) =>{
    let itemPedidos = await buscarItemPedidos()
    res.json(itemPedidos)
})
app.get('/firma/1.0.0/itemPedido/:id', async (req, res) =>{
    let id = parseInt( req.params.id)
    let itemPedido = await buscarItemPedido(id)
    res.json(itemPedido)
})
app.post('/firma/1.0.0/itemPedido', async (req, res) =>{
    let {id, id_pedido, id_produto, qnt} = req.body
    const infos = [id, id_pedido, id_produto, qnt]
    let resultItemPedido = await incluirItemPedido(infos)
    res.json(resultItemPedido)
})

//pedido

app.get('/firma/1.0.0/pedido', async (req, res) =>{
    let Pedidos = await buscarPedidos()
    res.json(Pedidos)
})
app.get('/firma/1.0.0/pedido/:numero', async (req, res) =>{
    let numero = parseInt( req.params.numero)
    let Pedido = await buscarPedido(numero)
    res.json(Pedido)
})
app.post('/firma/1.0.0/pedido', async (req, res) =>{
    let {numero, data_elaboracao, cliente_id} = req.body
    const infos = [numero, data_elaboracao, cliente_id]
    let resultPedido = await incluirPedido(infos)
    res.json(resultPedido)
})


app.listen(process.env.PORTA, () => {
    console.log(`Operando na porta ${process.env.PORTA}`), 
    testarConexao(conexao())
})