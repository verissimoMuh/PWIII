const {conexao} = require('../conexao.js')

async function incluirEndereco(infos){
    const data = [infos]
    const sql = `INSERT INTO tbl_endereco (id, logradouro, cep, numero, bairro,  cidade) VALUES ?`
    const conn = await conexao()
    
    try {
        // Executar a consulta
        const [resultEndereco] = await conn.query(sql,[data]);

        await conn.end()
        return resultEndereco
      } catch (err) {
        return err.message
      }
}

module.exports = {incluirEndereco}