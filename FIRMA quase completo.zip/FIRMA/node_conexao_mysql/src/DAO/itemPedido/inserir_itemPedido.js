const {conexao} = require('../conexao.js')

async function incluirItemPedido(infos){
    const data = [infos]
    const sql = `INSERT INTO tbl_itempedido (id, id_pedido, id_produto, qnt) values ?`
    const conn = await conexao()
    
    try {
        // Executar a consulta
        const [resultItemPedido] = await conn.query(sql,[data]);

        await conn.end()
        return resultItemPedido
      } catch (err) {
        return err.message
      }
}

module.exports = {incluirItemPedido}